-- Test Query 1: A quote to show the customer info, the device type,
-- the service needed along with the cost, and expected repair time.
SELECT 
    sr.RequestID,
    sr.RequestDate,
    c.FirstName,
    c.LastName,
    c.PhoneNo,
    c.Address,
    c.City,
    c.State,
    c.ZipCode,
    d.Description AS DeviceType,
    s.Description AS Service,
    s.Cost,
    s.EstRepairTime
FROM
    customers AS c
        INNER JOIN
    servicerequests AS sr USING (CustomerID)
        INNER JOIN
    requestdetails USING (RequestID)
        INNER JOIN
    devices AS d USING (DeviceID)
        INNER JOIN
    services AS s USING (ServiceID);

-- Test Query 2: The number of devices each tech repaired.
SELECT 
    CONCAT_WS(' ', t.FirstName, t.LastName) AS Name,
    d.Description AS DeviceType,
    COUNT(sr.TechnicianID) AS NumberRepaired
FROM
    servicerequests AS sr
        LEFT JOIN
    technicians AS t USING (TechnicianID)
        LEFT JOIN
    requestdetails USING (RequestID)
        LEFT JOIN
    devices AS d USING (DeviceID)
GROUP BY Name , DeviceType
ORDER BY Name;

-- Test Query 3: A queue screen to show the device type, service needed,
-- the notes / issues of the item and should be sorted by oldest request first.
SELECT 
    sr.RequestDate,
    s.Description AS Service,
    d.Description AS DeviceType,
    rd.Notes
FROM
    servicerequests AS sr
        LEFT JOIN
    services AS s USING (ServiceID)
        LEFT JOIN
    requestdetails AS rd USING (RequestID)
        LEFT JOIN
    devices AS d USING (DeviceID)
ORDER BY sr.RequestDate;

-- Test Query 4: Number of times each device has been serviced, sorted most to fewest.
SELECT 
    d.DeviceID,
    d.Description AS DeviceType,
    COUNT(rd.DeviceID) AS NumberServiced
FROM
    devices AS d
        LEFT JOIN
	requestdetails AS rd USING (DeviceID)
GROUP BY DeviceID, DeviceType
ORDER BY NumberServiced DESC;