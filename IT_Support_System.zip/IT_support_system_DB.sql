-- IT Support System Database Creation Script
-- Developed by Tyler Haack
-- Version: 1.0
-- Modified Date: 02/17/2023
CREATE DATABASE IF NOT EXISTS `ITsupportsystem`;

USE `ITsupportsystem`;

CREATE TABLE `customers` (
    `CustomerID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `FirstName` VARCHAR(25) NOT NULL,
    `LastName` VARCHAR(25) NOT NULL,
    `PhoneNo` VARCHAR(15) DEFAULT NULL,
    `Address` VARCHAR(50) DEFAULT NULL,
    `City` VARCHAR(20) DEFAULT NULL,
    `State` VARCHAR(2) DEFAULT NULL,
    `ZipCode` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`CustomerID`)
)  AUTO_INCREMENT=100;

CREATE TABLE `technicians` (
    `TechnicianID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `FirstName` VARCHAR(25) NOT NULL,
    `LastName` VARCHAR(25) NOT NULL,
    `Title` VARCHAR(25) DEFAULT NULL,
    `Salary` DECIMAL(6 , 0 ) DEFAULT NULL,
    `PhoneNo` VARCHAR(15) DEFAULT NULL,
    `Address` VARCHAR(50) DEFAULT NULL,
    `City` VARCHAR(20) DEFAULT NULL,
    `State` VARCHAR(2) DEFAULT NULL,
    `ZipCode` VARCHAR(10) DEFAULT NULL,
    PRIMARY KEY (`TechnicianID`)
)  AUTO_INCREMENT=200;

CREATE TABLE `services` (
    `ServiceID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(50) NOT NULL,
    `Cost` DECIMAL(6 , 2 ) DEFAULT NULL,
    `EstRepairTime` TIME DEFAULT NULL,
    PRIMARY KEY (`ServiceID`)
)  AUTO_INCREMENT=300;

CREATE TABLE `devices` (
    `DeviceID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `Description` VARCHAR(50) NOT NULL,
    PRIMARY KEY (`DeviceID`)
)  AUTO_INCREMENT=400;

CREATE TABLE `parts` (
    `PartID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `Category` VARCHAR(20) NOT NULL,
    `Description` VARCHAR(50) NOT NULL,
    `Cost` DECIMAL(6 , 2 ) DEFAULT NULL,
    `OnHand` SMALLINT DEFAULT NULL,
    PRIMARY KEY (`PartID`)
)  AUTO_INCREMENT=500;

CREATE TABLE `servicerequests` (
    `RequestID` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `CustomerID` INT UNSIGNED NOT NULL,
    `RequestDate` DATETIME NOT NULL,
    `ServiceID` INT UNSIGNED NOT NULL,
    `TechnicianID` INT UNSIGNED NOT NULL,
    `PartID` INT UNSIGNED DEFAULT NULL,
    `PartQtyUsed` TINYINT DEFAULT NULL,
    PRIMARY KEY (`RequestID`)
)  AUTO_INCREMENT=1;

CREATE TABLE `requestdetails` (
    `DeviceID` INT UNSIGNED NOT NULL,
    `RequestID` INT UNSIGNED NOT NULL,
    `Notes` VARCHAR(255) DEFAULT NULL,
    PRIMARY KEY (`DeviceID` , `RequestID`)
);

INSERT INTO `customers` (`FirstName`, `LastName`, `PhoneNo`, `Address`, `City`, `State`, `ZipCode`) VALUES
						("Ted", "Lasso", "555-333-1234", "1234 Default St.", "Altoona", "WI", "54720"),
						("Michael", "Scott", "555-333-4567", "4567 Default Ave", "Altoona", "WI", "54720"),
						("Tony", "Stark", "555-333-7890", "7890 Random Rd.", "Eau Claire", "WI", "54701"),
						("Aaron", "Rodgers", "555-777-2468", "2468 Random Dr.", "Eau Claire", "WI", "54702"),
						("Tom", "Brady", "555-777-1357", "1357 Test Blvd", "Chippewa Falls", "WI", "54729"),
						("Red", "Foreman", "555-777-9090", "9090 Test Way", "Chippewa Falls", "WI", "54729");

INSERT INTO `devices` (`Description`) VALUES
					("Laptops"),
					("Desktops"),
					("Printers"),
					("Phones / Tablets"),
					("Consumer level Routers"),
					("Peripheral devices (Mouse, Keyboard, etc.)"),
					("Projectors");

INSERT INTO `services` (`Description`, `Cost`, `EstRepairTime`) VALUES
						("Cracked Screen", "10.00", "000:30:00"),
						("Replace Battery", "10.00", "000:30:00"),
						("Motherboard Replacement", "50.00", "1:00:00"),
						("Lamp Bulb Replacement", "40.00", "1:00:00"),
						("Configure Home Router", "30.00", "000:45:00"),
						("Virus Removal", "20.00", "000:45:00"),
                        ("Replace Memory", "75.00", "1:30:00"),
                        ("Re-install OS", "25.00", "000:30:00"),
                        ("Install VPN", "25.00", "000:30:00");

INSERT INTO `technicians` (`FirstName`, `LastName`, `Title`, `Salary`, `PhoneNo`, `Address`, `City`, `State`, `ZipCode`) VALUES
					("Olivia", "Benton", "Lead Technician", 80000, "555-777-8122", "4110 Old Redmond Rd.", "Eau Claire", "WI", "54702"),
					("Tyler", "Haack", "Asst Lead Technician", 75000, "555-777-6236", "20th Ave. E.", "Chippewa Falls", "WI", "54729"),
                    ("Andrew", "Fuller", "Technician", 60000, "555-777-9482", "908 W. Capital Way", "Chippewa Falls", "WI", "54729"),
                    ("Janet", "Leverling", "Technician", 60000, "555-777-3412", "722 Moss Bay Blvd.", "Eau Claire", "WI", "54702"),
                    ("Nancy", "Davolio", "Technician", 60000, "555-777-9857", "9857 Main St.", "Eau Claire", "WI", "54702");

INSERT INTO `servicerequests` (`CustomerID`, `RequestDate`, `ServiceID`, `TechnicianID`) VALUES
								("100", "2022-11-11 13:23:44", "300", "201"),
                                ("101", "2022-11-15 15:45:21", "303", "202"),
                                ("102", "2022-11-23 11:12:01", "301", "203"),
                                ("103", "2022-11-27 14:56:59", "306", "204"),
                                ("103", "2022-11-27 15:00:37", "304", "204"),
                                ("104", "2022-12-04 09:10:11", "302", "200"),
                                ("105", "2022-12-04 12:21:22", "303", "200"),
                                ("106", "2022-12-09 17:43:52", "308", "203"),
                                ("107", "2022-12-13 13:51:25", "305", "202"),
                                ("108", "2022-12-18 08:30:45", "307", "203");


INSERT INTO `requestdetails` (`DeviceID`, `RequestID`, `Notes`) VALUES
								("400", "1",""),
                                ("400", "2",""),
                                ("403", "3","Corroded battery"),
                                ("401", "4",""),
                                ("404", "5",""),
                                ("400", "6","Replacement due to liquid damage"),
                                ("401", "7",""),
                                ("403", "8",""),
                                ("403", "9",""),
                                ("402", "10","Legacy printer");